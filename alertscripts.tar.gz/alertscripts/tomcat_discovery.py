#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/9/17 下午9:13
# @Author  : lin
# @File    : discovery tomcat.py

import json,subprocess

args="sudo /bin/find  /data/tomcat/ -name 'server.xml'|awk -F '/' '{print $4}'|sort|uniq"

t=subprocess.Popen(args,shell=True,stdout=subprocess.PIPE).communicate()[0]

tomcats=[]

for tomcat in t.split('\n'):
    if len(tomcat) != 0:
	        tomcats.append({'{#TOMCAT_NAME}':tomcat})
print json.dumps({'data':tomcats},indent=4,separators=(',',':'))
