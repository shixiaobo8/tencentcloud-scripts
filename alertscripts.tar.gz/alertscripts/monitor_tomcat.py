#!/usr/bin/python
# -*- coding:utf8 -*-
import urllib2
import xml.dom.minidom
import sys
import commands

 
server_port = sys.argv[1]
url = """http://127.0.0.1:"""+server_port+"""/manager/status?XML=true"""
username = 'zabbix'
password = 'zabbix'

# tomcat 存活状态 1 表示存活,2表示down 机 默认为1
server_active = 1
passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
passman.add_password(None, url, username, password)
authhandler = urllib2.HTTPBasicAuthHandler(passman)
opener = urllib2.build_opener(authhandler)
urllib2.install_opener(opener)
xmlData = ''
doc = ''
try:
	pagehandle = urllib2.urlopen(url,timeout=10)
	xmlData = pagehandle.read()
except Exception,e:
	server_active = 0
	print server_active
	sys.exit(1)
doc = xml.dom.minidom.parseString(xmlData)
	

item = sys.argv[2]
 
if item == "memory.free":
    print  doc.getElementsByTagName("memory")[0].getAttribute("free")
elif item == "memory.total":
    print  doc.getElementsByTagName("memory")[0].getAttribute("total")
elif item == "memory.max":
    print  doc.getElementsByTagName("memory")[0].getAttribute("max")
elif item == "threadInfo.maxThreads":
    print  doc.getElementsByTagName("threadInfo")[0].getAttribute("maxThreads")
elif item == "threadInfo.currentThreadCount":
    print  doc.getElementsByTagName("threadInfo")[0].getAttribute("currentThreadCount")
elif item == "threadInfo.currentThreadsBusy":
    print  doc.getElementsByTagName("threadInfo")[0].getAttribute("currentThreadsBusy")
elif item == "requestInfo.maxTime":
    print  doc.getElementsByTagName("requestInfo")[0].getAttribute("maxTime")
elif item == "requestInfo.processingTime":
    print  doc.getElementsByTagName("requestInfo")[0].getAttribute("processingTime")
elif item == "requestInfo.requestCount":
    print  doc.getElementsByTagName("requestInfo")[0].getAttribute("requestCount")
elif item == "requestInfo.errorCount":
    print  doc.getElementsByTagName("requestInfo")[0].getAttribute("errorCount")
elif item == "requestInfo.bytesReceived":
    print  doc.getElementsByTagName("requestInfo")[0].getAttribute("bytesReceived")
elif item == "requestInfo.bytesSent":
    print  doc.getElementsByTagName("requestInfo")[0].getAttribute("bytesSent")
elif item == "PS.Eden.Space.usageInit":
    print  doc.getElementsByTagName("memorypool")[0].getAttribute("usageInit")
elif item == "PS.Eden.Space.usageCommitted":
    print  doc.getElementsByTagName("memorypool")[0].getAttribute("usageCommitted")
elif item == "PS.Eden.Space.usageMax":
    print  doc.getElementsByTagName("memorypool")[0].getAttribute("usageMax")
elif item == "PS.Eden.Space.usageUsed":
    print  doc.getElementsByTagName("memorypool")[0].getAttribute("usageUsed")
elif item == "PS.Old.Gen.usageInit":
    print  doc.getElementsByTagName("memorypool")[1].getAttribute("usageInit")
elif item == "PS.Old.Gen.usageCommitted":
    print  doc.getElementsByTagName("memorypool")[1].getAttribute("usageCommitted")
elif item == "PS.Old.Gen.usageMax":
    print  doc.getElementsByTagName("memorypool")[1].getAttribute("usageMax")
elif item == "PS.Old.Gen.usageUsed":
    print  doc.getElementsByTagName("memorypool")[1].getAttribute("usageUsed")
elif item == "PS.Survivor.Space.usageInit":
    print  doc.getElementsByTagName("memorypool")[2].getAttribute("usageInit")
elif item == "PS.Survivor.Space.usageCommitted":
    print  doc.getElementsByTagName("memorypool")[2].getAttribute("usageCommitted")
elif item == "PS.Survivor.Space.usageMax":
    print  doc.getElementsByTagName("memorypool")[2].getAttribute("usageMax")
elif item == "PS.Survivor.Space.usageUsed":
    print  doc.getElementsByTagName("memorypool")[2].getAttribute("usageUsed")
elif item == "Code.Cache.usageInit":
    print  doc.getElementsByTagName("memorypool")[3].getAttribute("usageInit")
elif item == "Code.Cache.usageCommitted":
    print  doc.getElementsByTagName("memorypool")[3].getAttribute("usageCommitted")
elif item == "Code.Cache.usageMax":
    print  doc.getElementsByTagName("memorypool")[3].getAttribute("usageMax")
elif item == "Code.Cache.usageUsed":
    print  doc.getElementsByTagName("memorypool")[3].getAttribute("usageUsed")
elif item == "Compressed.Class.Space.usageInit":
    print  doc.getElementsByTagName("memorypool")[4].getAttribute("usageInit")
elif item == "Compressed.Class.Space.usageCommitted":
    print  doc.getElementsByTagName("memorypool")[4].getAttribute("usageCommitted")
elif item == "Compressed.Class.Space.usageMax":
    print  doc.getElementsByTagName("memorypool")[4].getAttribute("usageMax")
elif item == "Compressed.Class.Space.usageUsed":
    print  doc.getElementsByTagName("memorypool")[4].getAttribute("usageUsed")
elif item == "Metaspace.usageInit":
    print  doc.getElementsByTagName("memorypool")[5].getAttribute("usageInit")
elif item == "Metaspace.usageCommitted":
    print  doc.getElementsByTagName("memorypool")[5].getAttribute("usageCommitted")
elif item == "Metaspace.usageMax":
    print  doc.getElementsByTagName("memorypool")[5].getAttribute("usageMax")
elif item == "Metaspace.usageUsed":
    print  doc.getElementsByTagName("memorypool")[5].getAttribute("usageUsed")
elif item == "tomcat_server.active":
	print server_active
else:
    print "unsupport item."
