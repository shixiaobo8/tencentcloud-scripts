#!/bin/bash
source /etc/profile
[  $# -ne 2 ] && echo 'The scripts need 2 parameters'&&exit 1 
TOMCAT_NAME=$1
ITEM=$2

JMX_PORT=`ps -ef|grep $1|grep -vE 'grep|sh'|awk -F '=' '{print $6}'|awk '{print $1}'`
#读取server.xml配置文件，获取端口
xml=/usr/local/$1/conf/server.xml

PORT=`sed -n '69'p $xml |awk -F '[= " ]+' '{print $4}' `
cmd=/etc/zabbix/zb_monitor_script/cmdline-jmxclient-0.10.3.jar
logdir=/tmp/zabbix_tmp
[ ! -d "$logdir" ] && mkdir -p $logdir && chmod 777 $logdir
cd $logdir

function HeapMemoryUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Memory HeapMemoryUsage 2> $ITEM.$JMX_PORT
}

function EdenSpaceUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Eden\ Space Usage  2> $ITEM.$JMX_PORT
}


function SurvivorSpaceUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Survivor\ Space Usage   2> $ITEM.$JMX_PORT
}

function TenuredGenUsage() 
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Tenured\ Gen Usage  2> $ITEM.$JMX_PORT
}

function NonHeapMemoryUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Memory  NonHeapMemoryUsage 2> $ITEM.$JMX_PORT
}

function MetaspaceUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Metaspace Usage 2> $ITEM.$JMX_PORT
}

function CodeCacheUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Code\ Cache Usage 2> $ITEM.$JMX_PORT
}

function CompressedClassSpaceUsage()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Compressed\ Class\ Space Usage 2> $ITEM.$JMX_PORT
}

function TotalLoadedClassCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=ClassLoading TotalLoadedClassCount  2> $ITEM.$JMX_PORT
}

function LoadedClassCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=ClassLoading LoadedClassCount  2> $ITEM.$JMX_PORT
}

function UnloadedClassCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=ClassLoading UnloadedClassCount  2> $ITEM.$JMX_PORT
}

function TotalStartedThreadCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Threading TotalStartedThreadCount  2> $ITEM.$JMX_PORT
}

function ThreadCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Threading ThreadCount 2> $ITEM.$JMX_PORT
}

function PeakThreadCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Threading PeakThreadCount  2> $ITEM.$JMX_PORT
}

function maxThreads()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=ThreadPool maxThreads  2> $ITEM.$JMX_PORT
}

function currentThreadCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=ThreadPool currentThreadCount 2>$ITEM.$JMX_PORT
}

function currentThreadsBusy()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=ThreadPool currentThreadsBusy 2>$ITEM.$JMX_PORT      
}

function GlobalRequestProcessor_bytesReceived()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=GlobalRequestProcessor bytesReceived 2>$ITEM.$JMX_PORT      
}

function GlobalRequestProcessor_bytesSent()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=GlobalRequestProcessor bytesSent 2>$ITEM.$JMX_PORT      
}

function requestCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=GlobalRequestProcessor requestCount 2>$ITEM.$JMX_PORT      
}

function errorCount()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT Catalina:name=\"http-nio-$PORT\",type=GlobalRequestProcessor errorCount 2>$ITEM.$JMX_PORT    
}

function jvmUptime()
{
	java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Runtime Uptime 2> $ITEM.$JMX_PORT  
}



# function collectdata()
# {
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Memory HeapMemoryUsage 2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Eden\ Space Usage  2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Survivor\ Space Usage   2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Tenured\ Gen Usage  2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=Memory  NonHeapMemoryUsage 2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Metaspace Usage 2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Code\ Cache Usage  2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=MemoryPool,name=Compressed\ Class\ Space Usage 2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=ClassLoading TotalLoadedClassCount  2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=ClassLoading LoadedClassCount  2> $ITEM.$JMX_PORT
# java  -jar $cmd - 127.0.0.1:$JMX_PORT java.lang:type=ClassLoading UnloadedClassCount  2> $ITEM.$JMX_PORT
# }

case $ITEM in
#统计堆空间堆                   
HeapMemoryUsage.max)
HeapMemoryUsage
sed -n '4p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
HeapMemoryUsage.used)
HeapMemoryUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
HeapMemoryUsage.committed)
HeapMemoryUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计伊甸元代空间
EdenSpaceUsage.max)
EdenSpaceUsage
sed -n '4p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
EdenSpaceUsage.used)
EdenSpaceUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
EdenSpaceUsage.committed)
EdenSpaceUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计内存池survivor space(幸存区空间)
SurvivorSpaceUsage.max)
SurvivorSpaceUsage
sed -n '4p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
SurvivorSpaceUsage.used)
SurvivorSpaceUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
SurvivorSpaceUsage.committed)
SurvivorSpaceUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计内存池old gen(Tenured Gen 老年代空间)
TenuredGenUsage.max)
TenuredGenUsage
sed -n '4p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
TenuredGenUsage.used)
TenuredGenUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
TenuredGenUsage.committed)
TenuredGenUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计非堆内存
NonHeapMemoryUsage.used)
NonHeapMemoryUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
NonHeapMemoryUsage.committed)
NonHeapMemoryUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计内存池meta space(元数据空间)
MetaspaceUsage.used)
MetaspaceUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
MetaspaceUsage.committed)
MetaspaceUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计内存池code cache(代码缓存)
CodeCacheUsage.max)
CodeCacheUsage
sed -n '4p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
CodeCacheUsage.used)
CodeCacheUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
CodeCacheUsage.committed)
CodeCacheUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计compressed class space（压缩类的空间）
CompressedClassSpaceUsage.max)
CompressedClassSpaceUsage
sed -n '4p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
CompressedClassSpaceUsage.used)
CompressedClassSpaceUsage
sed -n '5p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
CompressedClassSpaceUsage.committed)
CompressedClassSpaceUsage
sed -n '2p' $ITEM.$JMX_PORT|awk '{print $2}'
;;
#统计类加载的个数
ClassLoading.TotalLoadedClassCount)
TotalLoadedClassCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
ClassLoading.LoadedClassCount)
LoadedClassCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
ClassLoading.UnloadedClassCount)
UnloadedClassCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
#统计java线程数
Threading.TotalStartedThreadCount)
TotalStartedThreadCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
ThreadCount)
ThreadCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
PeakThreadCount)
PeakThreadCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
#统计tomcat的线程数
maxThreads)
maxThreads
awk '{print $6}' $ITEM.$JMX_PORT
;;
currentThreadCount)
currentThreadCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
currentThreadsBusy)
currentThreadsBusy
awk '{print $6}' $ITEM.$JMX_PORT
;;
#统计tomcat网络流量
bytesReceived)
GlobalRequestProcessor_bytesReceived
awk '{print $6}' $ITEM.$JMX_PORT
;;
bytesSent)
GlobalRequestProcessor_bytesSent
awk '{print $6}' $ITEM.$JMX_PORT
;;
#统计tomcat的请求数
requestCount)
requestCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
errorCount)
errorCount
awk '{print $6}' $ITEM.$JMX_PORT
;;
#jvm运行时间，如果运行时间没获取到数据，则表示jvm stop ，从而判断tomcat stop
jvmUptime)
jvmUptime
[ $? -eq 0 ]&&awk '{print $6/1000}' $ITEM.$JMX_PORT||echo 0
;;
esac
