#!/usr/bin/env python2.7
# -*- coding:utf8 -*-

import os
import json
import sys

ports = {
	'data' : [
		{
			"{#TOMCAT_HTTP_PORT}":"17080",
			"{#TOMCAT_NAME}":"tomcat-17080"
		},
		{
			"{#TOMCAT_HTTP_PORT}":"18080",
			"{#TOMCAT_NAME}":"tomcat-18080"
		},
		{
			"{#TOMCAT_HTTP_PORT}":"19080",
			"{#TOMCAT_NAME}":"tomcat-19080"
		},
		{
			"{#TOMCAT_HTTP_PORT}":"20080",
			"{#TOMCAT_NAME}":"tomcat-20080"
		},
	
	]
}


print json.dumps(ports,sort_keys=False,indent=4,separators=(',',':'))
